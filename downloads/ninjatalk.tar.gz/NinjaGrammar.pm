package NinjaGrammar;

use strict;
use warnings;

sub grammar {
    <<GRAMAR
        <autotree>
        top: statement(s? /;/) | <error>

        statement: set | print_stmt | if_stmt | function_def | function_call | get

        get: ident 

        set: ident ':' expr

        print_stmt: 'print ' expr

        function_def: 'function' function_name args block

        function_call: function_name '(' expr(s /,/) ')'

        args: '(' ident(s /,/) ')'

        if_stmt: 'if ' expr block <commit> ('else' block)(?)

        block: '{' statement(s? /;/) '}'

        ident:  ...!keyword /[a-zA-Z][a-zA-Z0-9-_]*/ | <error>

        function_name:  ...!keyword /[a-zA-Z][a-zA-Z0-9-_]*/

        keyword: 'if' | 'print' | 'true' | 'false' | 'function'

        expr: logical_expr | basic_expr

        basic_expr: '(' expr ')' | ident | literal

        logical_expr: basic_expr ( '&&' | '||' ) expr

        literal: string | number | boolean

        boolean: 'true' | 'false'

        number: /\\d+/

        string: '"' <skip:'' >  /[\\w\\s\\\\]*/ '"' 
GRAMAR
}

1;
