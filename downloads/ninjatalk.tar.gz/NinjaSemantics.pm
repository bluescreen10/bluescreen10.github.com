package NinjaSemantics;

use strict;
use warnings;

my $globals = {};
my @blocks;

sub emit {
    my ( $class, $target ) = @_;
    my $method = ref $target;
    if ( $class->can($method) ) {
        $class->$method($target);
    }
}

sub top {
    my ( $class, $ast ) = @_;
    my @statements = map { $class->emit($_) } @{ $ast->{'statement(s?)'} };
    return join( ";\n", @statements );
}

sub statement {
    my ( $class, $ast ) = @_;
    return $class->emit( $ast->{set} )          if defined $ast->{set};
    return $class->emit( $ast->{get} )          if defined $ast->{get};
    return $class->emit( $ast->{print_stmt} )   if defined $ast->{print_stmt};
    return $class->emit( $ast->{if_stmt} )      if defined $ast->{if_stmt};
    return $class->emit( $ast->{function_def} ) if defined $ast->{function_def};
    return $class->emit( $ast->{function_call} )
      if defined $ast->{function_call};
    '';
}

sub function_def {
    my ( $class, $ast ) = @_;
    my $code = 'sub '
      . $class->emit( $ast->{function_name} ) . "{\n"
      . $class->emit( $ast->{args} )
      . $class->emit( $ast->{block} ) . "\n}";
}

sub function_name {
    my ( $class, $ast ) = @_;
    return $ast->{__PATTERN1__};
}

sub args {
    my ( $class, $ast ) = @_;

    my @args = map { $class->emit($_) } @{ $ast->{'ident(s)'} };
    'my (' . join( ',', @args ) . ') = @_;';
}

sub function_call {
    my ( $class, $ast ) = @_;
    my @args = map { $class->emit($_) } @{ $ast->{'expr(s)'} };

    $class->emit( $ast->{function_name} ) . '(' . join( ',', @args ) . ')';
}

sub get {
    my ( $class, $ast ) = @_;
    return $class->emit( $ast->{ident} );
}

sub set {
    my ( $class, $ast ) = @_;
    my $ident = $class->emit( $ast->{ident} );
    my $prefix = ( $globals->{$ident}++ ) ? '' : 'my ';
    return "$prefix$ident=" . $class->emit( $ast->{expr} );
}

sub ident {
    my ( $class, $ast ) = @_;
    return '$' . $ast->{__PATTERN1__};
}

sub expr {
    my ( $class, $ast ) = @_;
    return $class->emit( $ast->{logical_expr} )
      if defined $ast->{logical_expr};
    return $class->emit( $ast->{basic_expr} )
      if defined $ast->{basic_expr};
}

sub basic_expr {
    my ( $class, $ast ) = @_;
    return $class->emit( $ast->{ident} )   if defined $ast->{ident};
    return $class->emit( $ast->{literal} ) if defined $ast->{literal};
    return '(' . $class->emit( $ast->{expr} ) . ')'
      if defined $ast->{expr};
}

sub logical_expr {
    my ( $class, $ast ) = @_;
    if (
        $ast->{_alternation_1_of_production_1_of_rule_logical_expr}->{__VALUE__}
        eq '&&' )
    {
        return $class->emit( $ast->{basic_expr} ) . ' && '
          . $class->emit( $ast->{expr} );
    }
    else {
        return $class->emit( $ast->{basic_expr} ) . ' || '
          . $class->emit( $ast->{expr} );
    }
}

sub literal {
    my ( $class, $ast ) = @_;
    return $class->emit( $ast->{string} )  if defined $ast->{string};
    return $class->emit( $ast->{number} )  if defined $ast->{number};
    return $class->emit( $ast->{boolean} ) if defined $ast->{boolean};
}

sub number {
    my ( $class, $ast ) = @_;
    return $ast->{__VALUE__};
}

sub string {
    my ( $class, $ast ) = @_;
    return '"' . $ast->{__PATTERN1__} . '"';
}

sub print_stmt {
    my ( $class, $ast ) = @_;
    return 'print ' . $class->emit( $ast->{expr} );
}

sub boolean {
    my ( $class, $ast ) = @_;
    if ( $ast->{__VALUE__} eq 'true' ) {
        return "1";
    }
    return "0";
}

sub block {
    my ( $class, $ast ) = @_;
    my @statements =
      map { $class->emit($_) } @{ $ast->{'statement(s?)'} };
    return "{\n" . join( ";\n", @statements ) . "\n}\n";
}

sub if_stmt {
    my ( $class, $ast ) = @_;

    my $else_code = '';

    if ( @{ $ast->{'_alternation_1_of_production_1_of_rule_if_stmt(?)'} } ) {
        $else_code =
          "\n\nelse \n"
          . $class->emit(
            $ast->{'_alternation_1_of_production_1_of_rule_if_stmt(?)'}->[0]
              ->{block} );
    }

    return
        'if('
      . $class->emit( $ast->{expr} )
      . ")\n"
      . $class->emit( $ast->{block} )
      . $else_code . "\n";

}

1;
